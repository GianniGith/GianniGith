#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#define TAILLE_FICHIER 62
#include <iostream>
#include <string.h>
#include <fstream>
#include <vector>
#include <sstream>
#include <allegro.h>
#include <limits>
#include <queue>
#include <algorithm>

void Initialisation();
void visualisation_graphique();
void menu();

class Type_avion
{
    private:
        std::string m_type;
        int m_consommation;
        int m_capacite_carburant;
        int m_capacite_carburant_actuel;
        int m_altitude;
        int m_x;
        int m_y;
        int m_deplacement_x;
        int m_deplacement_y;

    public:

        Type_avion()
        {
            m_type = "";
            m_consommation = 0;
            m_capacite_carburant = 0;
        }
        //Getteur
        int GetX()
        {
            return m_x;
        }
        int GetY()
        {
            return m_y;
        }
        int GetdeplacementX()
        {
            return m_deplacement_x;
        }
        int GetdeplacementY()
        {
            return m_deplacement_y;
        }
        int GetCapaciteCarburantActuel()
        {
            return m_capacite_carburant_actuel;
        }

        int Getaltitude()
        {
            return m_altitude;
        }
        std::string GetType()
        {
            return m_type;
        }
        int GetConsommation()
        {
            return m_consommation;
        }
        int GetCapaciteCarburant()
        {
            return m_capacite_carburant;
        }

        //Setteur
        void SetType(std::string _type)
        {
            m_type = _type;
        }
        void SetConsommation(int _conso)
        {
            m_consommation = _conso;
        }
        void SetCapaciteCarburant(int _capacite_carburant)
        {
            m_capacite_carburant = _capacite_carburant;
        }
        void SetCapaciteCarburantMax(int _capacite_carburant_actuel)
        {
            m_capacite_carburant_actuel = _capacite_carburant_actuel;
        }
        void SetAltitude(int _altitude)
        {
            m_altitude = _altitude;
        }
        void SetX(int _x)
        {
            m_x = _x;
        }
        void SetY(int _y)
        {
            m_y = _y;
        }
        void SetDeplacementX(int _deplacement_x)
        {
            m_deplacement_x = _deplacement_x;
        }
        void SetDeplacementY(int _deplacement_y)
        {
            m_deplacement_y = _deplacement_y;
        }

};

class Aeroport
{
    private:
        std::string m_nom;
        std::vector<Type_avion> stockAvions;
        int m_nombrePistes;
        int m_nbPlaceAuSol;
        int m_delaiAttenteSol;
        int m_tempsAccesPiste;
        int m_tempsAtterDecol;
        int m_tempsAntiCol;
        int m_tempsBoucleAttente;

    public:

        Aeroport()
        {
            std::string m_nom = "";
            m_nombrePistes = 0;
            m_nbPlaceAuSol = 0;
            m_delaiAttenteSol = 0;
            m_tempsAccesPiste = 0;
            m_tempsAtterDecol = 0;
            m_tempsAntiCol = 0;
            m_tempsBoucleAttente = 0;

        }

        void SetType(Type_avion Type)
        {
            stockAvions.push_back(Type);
        }

        void setNom(std::string _nom)
        {
            m_nom = _nom;
        }

        void setNombrePistes(int _nombrePistes)
        {
            m_nombrePistes = _nombrePistes;
        }

        void setNbPlacesAuSol(int _nbPlaceAuSol)
        {
            m_nbPlaceAuSol = _nbPlaceAuSol;
        }

        void setDelaiAttenteSol(int _delaiAttenteSol)
        {
            m_delaiAttenteSol = _delaiAttenteSol;
        }

        void setTempsAccesPiste(int _tempsAccesPiste)
        {
            m_tempsAccesPiste = _tempsAccesPiste;
        }

        void setTempsAtterDecol(int _tempsAtterDecol)
        {
            m_tempsAtterDecol = _tempsAtterDecol;
        }

        void setTempsAntiCol(int _tempsAntiCol)
        {
            m_tempsAntiCol = _tempsAntiCol;
        }

        void setTempsBoucleAttente(int _tempsBoucleAttente)
        {
            m_tempsBoucleAttente = _tempsBoucleAttente;
        }

        std::string GetNom()const
        {
            return m_nom;
        }

        int GetNombrePistes()const
        {
            return m_nombrePistes;
        }

        int GetNbPlacesAuSol()const
        {
            return m_nbPlaceAuSol;
        }

        int GetDelaiAttenteSol()const
        {
            return m_delaiAttenteSol;
        }

        int GetTempsAccesPiste()const
        {
            return m_tempsAccesPiste;
        }

        int GetTempsAtterDecol()const
        {
            return m_tempsAtterDecol;
        }

        int GetTempsAntiCol()const
        {
            return m_tempsAntiCol;
        }

        int GetTempsBoucleAttente()const
        {
            return m_tempsBoucleAttente;
        }

        void Afficher()
        {
            std::cout << "Nom de l'aeroport:  " << m_nom <<std::endl;
            std::cout << "Nombre de pistes:  " << m_nombrePistes << std::endl;
            std::cout << "Nombre de places au sol:  " << m_nbPlaceAuSol << std::endl;
            std::cout << "Delai d'attente au sol:  " << m_delaiAttenteSol <<std::endl;
            std::cout << "Temps d'acces au pistes:  " << m_tempsAccesPiste <<std::endl;
            std::cout << "Temps d'atterissage/decolage:  " << m_tempsAtterDecol <<std::endl;
            std::cout << "Temps d'anticollision:  " << m_tempsAntiCol <<std::endl;
            std::cout << "Temps en boucle d'attente:  " << m_tempsBoucleAttente <<std::endl;
            std::cout <<std::endl<<std::endl<<std::endl;
        }

        void remplissageAvions()
        {
            std::ifstream ifs1{"Parametre avion_long.txt"};
            std::ifstream ifs2{"Parametre avion_moyen.txt"};
            std::ifstream ifs3{"Parametre avion_court.txt"};

            std::string _type;
            int _consommation;
            int _capacite;

            for (int i =0; i< m_nbPlaceAuSol; i++)
            {
                stockAvions.push_back(Type_avion());
                int alea = rand()%3;

                switch (alea)
                {
                        case 0:
                        {
                            ifs1>> _type;
                            ifs1>> _consommation;
                            ifs1>> _capacite;

                            stockAvions[i].SetType(_type);
                            stockAvions[i].SetConsommation(_consommation);
                            stockAvions[i].SetCapaciteCarburant(_capacite);
                            break;
                        }

                        case 1:
                        {
                            ifs2>> _type;
                            ifs2>> _consommation;
                            ifs2>> _capacite;

                            stockAvions[i].SetType(_type);
                            stockAvions[i].SetConsommation(_consommation);
                            stockAvions[i].SetCapaciteCarburant(_capacite);
                            break;
                        }

                        case 2:
                        {
                            ifs3>> _type;
                            ifs3>> _consommation;
                            ifs3>> _capacite;

                            stockAvions[i].SetType(_type);
                            stockAvions[i].SetConsommation(_consommation);
                            stockAvions[i].SetCapaciteCarburant(_capacite);
                            break;
                        }
                }
            }

            for(int j = 0; j<m_nbPlaceAuSol;j++)
            {
                std::cout<< "Avion"<<std::endl;
                std::cout<<"Type :" <<stockAvions[j].GetType()<<std::endl;
                std::cout<<"Capacite carburant :"<< stockAvions[j].GetCapaciteCarburant()<<std::endl;
                std::cout<<"Consommation :"<< stockAvions[j].GetConsommation()<<std::endl<<std::endl<<std::endl;
            }
        }

};


auto comp = [](const std::pair<int, int> &a, const std::pair<int, int> &b){return a.second > b.second;};
auto comparaison = [](const std::pair<int, int> &tempSom, const std::pair<int, int> &tempLong) {return tempSom.second > tempLong.second;};

class Reseau_aerien
{
    private :
        std::vector<Aeroport> m_aeroports;
        std::vector<std::vector<std::pair<Aeroport, int>>> m_reseau_aerien;
        int m_taille; //taille de notre graphe
        int m_ordre; //ordre de notre graphe

    public :
        //R�cuperation des donn�es de notre r�seau a�rien
        Reseau_aerien()
        {
            int ordre,taille,dist;
            std::string ville1,ville2;
            ///REMPLISSAGE M_AEROPORT
            chargementAeroports();
            std::ifstream ifs{"reseau_aerien.txt"};//on ouvre notre fichier reseau
            if(!ifs)
                throw std::runtime_error( "Impossible d'ouvrir en lecture donneesAero.txt" );
            ifs >> ordre;
            SetOrdre(ordre); //lecture de l'ordre de notre reseau (nb aeroports)
            if(ifs.fail())
                throw std::runtime_error("Probleme lecture ordre du graphe");
            //on alloue la place pour chaque sommet
            m_reseau_aerien.resize(m_ordre);
            ifs >> taille;//on lit le nbr de chemin
            SetTaille(taille);
            if(ifs.fail())
                throw std::runtime_error("Probleme lecture taille du graphe");
            for(int i=0;i<m_taille;++i)//on relis chaque aeroport � un autre
            {

                ifs>>ville1>>ville2>>dist;
                if(ifs.fail())
                    throw std::runtime_error("Probleme lecture chemins");
                m_reseau_aerien[indAeroport(ville1)].push_back(std::make_pair((m_aeroports[indAeroport(ville2)]),dist));

            }
        }

        void chargementAeroports()
        {
            std::ifstream ifs{"donneesAero.txt"};
            for(int i = 0; i< 7; i++)
            {
                m_aeroports.push_back(Aeroport()) ;
                if (!ifs) //Si probleme d'ouverture du ficher
                {
                    throw std::runtime_error( "Impossible d'ouvrir en lecture donneesAero.txt" ); //Traitement et renvoi de l'erreur associee
                }
                std::string _nom;
                ifs>> _nom;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture nom");
                }
                m_aeroports[i].setNom(_nom);

                int _nbPistes;
                ifs>> _nbPistes;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture nbPlaceAuSol");
                }
                m_aeroports[i].setNombrePistes(_nbPistes);

                int _nbPlaceSol;
                ifs>> _nbPlaceSol;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture nbPlaceAuSol");
                }
                m_aeroports[i].setNbPlacesAuSol(_nbPlaceSol);

                int _delAtSol;
                ifs>> _delAtSol;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture delaiAttenteSol");
                }
                m_aeroports[i].setDelaiAttenteSol(_delAtSol);

                int _tempsAccesPiste;
                ifs>> _tempsAccesPiste;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture tempsAccesPiste");
                }
                m_aeroports[i].setTempsAccesPiste(_tempsAccesPiste);

                int _tempsAtterDecol;
                ifs>> _tempsAtterDecol;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture tempsAtterDecol");
                }
                GetAeroports().at(i).setTempsAtterDecol(_tempsAtterDecol);

                int _tempsAntiCol;
                ifs>> _tempsAntiCol;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture tempsAntiCol");
                }
                m_aeroports[i].setTempsAntiCol(_tempsAntiCol);

                int _tempsBoucleAttente;
                ifs>> _tempsBoucleAttente;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture tempsBoucleAttente");
                }
                m_aeroports[i].setTempsBoucleAttente(_tempsBoucleAttente);
            }
        }

        void afficherAeroports()
        {
            for(int i = 0; i< GetOrdre() ; i++)
            {
                GetAeroports().at(i).Afficher();
                GetAeroports().at(i).remplissageAvions();
            }
        }

        //Fonction qui retourne l'indice en fct du nom de l'aeroport
        int indAeroport(std::string nom)
        {
            int temp =-1;
            for(int i=0;i<m_ordre;i++)
            {
                if(m_aeroports[i].GetNom() == nom)
                {
                     temp = i; //retourne l'indice de l'aeroport dans notre vecteur
                }

            }
            return temp;
        }



        //Sous-programme pour trouver le plus court chemin
        int Dijkstra(int a1, int a2, std::vector<int> *predecesseurs)
        {
            std::vector<int> distances(GetOrdre(), std::numeric_limits<int>::max()); //vecteur de la taille du nbr d'aeroport, contient la distance d'un aeroport initiale a un autre
            //distance[i] correspond � la distance du noeud de depart au noeud i
            distances[a1] = 0;//init a 0 pour aeroport initial

            std::vector<int> parents(m_ordre, -1); //Vecteur contenant les pr�d�cesseurs du sommet final permettant d'aller jusqu'au sommet initial

            //on utilise la classe priority queue de 2 classe pair  avec une fct de comparaison
            //notre comparateur nous permet de mettre le chemin le plus proche au haut
            std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, decltype(comp)> Q(comp);//chaque pair correspond a un aeroport et sa distance
            Q.push(std::make_pair(a1,0));//on init la queue prioritaire par le sommet de depart

            while(!Q.empty())//tant que la queue n'est pas vide
            {
                int a = Q.top().first;//on prend l'index du sommet le plus proche
                int b = Q.top().second;//prend en memoire la distance
                Q.pop();

                if(b <= distances[a])
                {
                    for(const auto& i : m_reseau_aerien.at(a)) // on parcourt le graphe � l'index du sommet a
                    {
                        auto a2 = indAeroport(i.first.GetNom());//ind aeroport connect� a a
                        auto b2 = i.second;//poid du chemin

                        if(distances[a] + b2 < distances[a2])//si distance de l'aeroport � a2 est plus court que l'ancien
                        {
                          distances[a2] = distances[a] + b2;//on reajuste la distance
                          parents[a2] = a; //actualise le parnet
                          Q.push(std::make_pair(a2, distances[a2]));//on ajoute le nv sommet
                        }
                    }
                }
            }

            predecesseurs->push_back(a2);


            for (auto p = parents[a2]; p != -1; p = parents[p]) //Parcours des pr�d�cesseurs
            {
                predecesseurs->push_back(p);
            }

            std::reverse(predecesseurs->begin(), predecesseurs->end());

            return distances[a2];
        }

        void AffichagePCC()
        {
            std::vector<std::pair<int,std::vector<int>>> listePrede (7);
            std::vector<int>::iterator it;
            std::vector<int> parents(GetOrdre(),-1);
            std::string A1,A2;
            std::vector<int> distances;

            do
            {
                std::cout<<"\nSAISIR LE NOM DE L'AEROPORT DE DEPART : "<<std::endl;
                std::cin>>A1;
            }while(A1 != "New-York" && A1 != "Londres" && A1 != "Brasilia" && A1 != "Alger" && A1 != "Tokyo" && A1 != "Sydney" && A1 != "Bangkok");


            for (int i = 0; i< m_ordre; i++)
            {
                listePrede[i].first = Dijkstra(indAeroport(A1),i, &listePrede[i].second);

                std::cout << "Chemin permettant d'aller de " << A1 << " a " << m_aeroports[i].GetNom() << " :" << std::endl;

                std::cout<< m_aeroports[*listePrede[i].second.begin()].GetNom() ;
                for (it = listePrede[i].second.begin()+1; it!=listePrede[i].second.end(); it++)
                {
                    std::cout<< "-->" << m_aeroports[*it].GetNom() ;
                }

                std::cout <<std::endl << "Distance entre " << A1 << " et " << m_aeroports[i].GetNom() << " :" << listePrede[i].first <<" kilometres"<< std::endl<< std::endl;
            }




           /* std::cout<<"\n\nAFFICHAGE DES PLUS COURTS CHEMIN"<<std::endl;
            std::cout<<"Affichage de l'ensemble des distances et chemins les plus court a partir de l'aeroport "<<A1<<std::endl;
            for(auto i = 0; i != m_ordre; ++i)//affichage de tous les chemins pour chaque noeud
            {
                std::cout << "De l'aeroport de "<<A1<<" a celui de "<<GetAeroports().at(i).GetNom()<<" : "<<distances[i]<<"Km"<<std::endl;
                std::cout << GetAeroports().at(i).GetNom();
                for(auto p = parents[i]; p != -1; p = parents[p])//on affiche tout le chemin
                {
                    std::cout << " <- " << GetAeroports().at(p).GetNom();
                }
                std::cout << std::endl;
            }*/

        }
        //Getters
        int GetOrdre()const
        {
            return m_ordre;
        }
        int GetTaille()const
        {
            return m_taille;
        }
        std::vector<Aeroport> GetAeroports()const
        {
            return m_aeroports;
        }
        std::vector<std::vector<std::pair<Aeroport, int>>> GetReseauAerien()const
        {
            return m_reseau_aerien;
        }
        //Setters
        void SetOrdre(int _ordre)
        {
            m_ordre=_ordre;
        }
        void SetTaille(int _taille)
        {
            m_taille=_taille;
        }
        void SetAeroports(std::vector<Aeroport> _aeroports)
        {
            m_aeroports=_aeroports;
        }
        void SetReseauAerien(std::vector<std::vector<std::pair<Aeroport, int>>> _reseau_aerien)
        {
            m_reseau_aerien=_reseau_aerien;
        }
};

class Menu
{
    private:
        int m_choix;

    public:
        Menu()
        {
            //rien a faire
        }
        //Methode
        void menuto()
        {
            int choix;
            std::cout <<std::endl<<"1 - La Liste des aeroports et leurs types"<<std::endl;
            std::cout <<"2 -Calculer et Afficher le reseau de l arbre"<<std::endl;
            std::cout <<"3 -Afficher le chemin le plus court de l arbre "<<std::endl;
            std::cout <<"4 -Arreter le programme"<<std::endl;

            do
            {
                std::cout <<"Quel est votre choix :";
                std::cin >>choix;

            }while(choix>4 || choix<0);

            Reseau_aerien reseau;

            switch(choix)
            {
                case 1 :
                {
                    reseau.afficherAeroports();
                    //reseau.afficherTousAeroports();
                    break;
                }

                case 2:
                {
                    Initialisation();
                    visualisation_graphique();
                    break;
                }
                case 3:
                {
                     //Afficher le chemin le plus court
                    reseau.AffichagePCC();
                    break;
                }

                case 4:
                    //allegro.exit();
                    break;
            }
        }
};

#include "menu.cpp"
#include "graphique.cpp"
#endif // HEADER_H_INCLUDED
