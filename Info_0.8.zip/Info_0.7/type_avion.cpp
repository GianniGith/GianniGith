#include "header.h"

Type_avion::Type_avion()
{
    m_type = "";
    m_consommation = 0;
    m_capacite_carburant = 0;
}

Type_avion::Type_avion(std::string _type, int _consommation, int _capacite)
{
    m_type = _type;
    m_consommation = _consommation;
    m_capacite_carburant = _capacite;
}
//Getteur
float Type_avion::GetX()const
{
    return m_x;
}
float Type_avion::GetY()const
{
    return m_y;
}
float Type_avion::GetdeplacementX()const
{
    return m_deplacement_x;
}
float Type_avion::GetdeplacementY()const
{
    return m_deplacement_y;
}
int Type_avion::GetCapaciteCarburantActuel()const
{
    return m_capacite_carburant_actuel;
}

int Type_avion::Getaltitude()const
{
    return m_altitude;
}
std::string Type_avion::GetType()const
{
    return m_type;
}
int Type_avion::GetConsommation()const
{
    return m_consommation;
}
int Type_avion::GetCapaciteCarburant()const
{
    return m_capacite_carburant;
}

//Setteur
void Type_avion::SetType(std::string _type)
{
    m_type = _type;
}
void Type_avion::SetConsommation(int _conso)
{
    m_consommation = _conso;
}
void Type_avion::SetCapaciteCarburant(int _capacite_carburant)
{
    m_capacite_carburant = _capacite_carburant;
}
void Type_avion::SetCapaciteCarburantMax(int _capacite_carburant_actuel)
{
    m_capacite_carburant_actuel = _capacite_carburant_actuel;
}
void Type_avion::SetAltitude(int _altitude)
{
    m_altitude = _altitude;
}
void Type_avion::SetX(float _x)
{
    m_x = _x;
}
void Type_avion::SetY(float _y)
{
    m_y = _y;
}
void Type_avion::SetDeplacementX(float x)
{
     m_deplacement_x=x;
}
void Type_avion::SetDeplacementY(float y)
{
    m_deplacement_y=y;
}
