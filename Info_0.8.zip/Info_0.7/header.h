#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#define TAILLE_FICHIER 62
#include <iostream>
#include <string.h>
#include <fstream>
#include <vector>
#include <sstream>
#include <allegro.h>
#include <limits>
#include <queue>
#include <algorithm>
#include <stdlib.h>
#include <time.h>


class Type_avion
{
    private:
        std::string m_type;
        int m_consommation;
        int m_capacite_carburant;
        int m_capacite_carburant_actuel;
        int m_altitude;
        float m_x;
        float m_y;
        float m_deplacement_x;
        float m_deplacement_y;

    public:

        Type_avion();
        Type_avion(std::string _type, int _consommation, int _capacite);
        //Getteur
        float GetX()const;
        float GetY()const;
        float GetdeplacementX()const;
        float GetdeplacementY()const;
        int GetCapaciteCarburantActuel()const;

        int Getaltitude()const;
        std::string GetType()const;
        int GetConsommation()const;
        int GetCapaciteCarburant()const;
        //Setteur
        void SetType(std::string _type);
        void SetConsommation(int _conso);
        void SetCapaciteCarburant(int _capacite_carburant);
        void SetCapaciteCarburantMax(int _capacite_carburant_actuel);
        void SetAltitude(int _altitude);
        void SetX(float _x);
        void SetY(float _y);
        void SetDeplacementX(float x);
        void SetDeplacementY(float y);
};

void decoco(Type_avion avions, std::string name)
{
    std::cout<< "Decollage"<< std::endl;
}

class Aeroport
{
    private:

        std::vector<std::pair<std::queue<Type_avion>,std::string>> m_piste;//piste "libre" ou "atterrissage" ou decollage"
        std::queue<Type_avion> m_transitionEntree;
        std::queue<Type_avion> m_transitionSortie;
        std::queue<Type_avion> m_stockage;
        std::queue<Type_avion> m_boucleAttente;
        std::string m_nom;
        std::vector<Type_avion> m_stockAvions;
        int m_nombrePistes;
        int m_nbPlaceAuSol;
        int m_placeUtilise;
        int m_delaiAttenteSol;
        int m_tempsAccesPiste;
        int m_tempsAtterDecol;
        int m_tempsAntiCol;
        int m_tempsBoucleAttente;

    public:

        Aeroport();

        //setteur
        void SetType(Type_avion Type);
        void  Setpistes(std::vector<std::pair<std::queue<Type_avion>,std::string>> _pistes);
        std::vector<std::pair<std::queue<Type_avion>,std::string>> Getpistes()const;
        void setNom(std::string _nom);
        void setPlaceUtilise(int _placeUtilise);
        int GetPlaceUtilise()const;
        void setNombrePistes(int _nombrePistes);

        std::vector<Type_avion> GetStockAvions()const;
        void SetStockAvions(std::vector<Type_avion> _stock);

        void setNbPlacesAuSol(int _nbPlaceAuSol);

        void setDelaiAttenteSol(int _delaiAttenteSol);

        void setTempsAccesPiste(int _tempsAccesPiste);
        void setTempsAtterDecol(int _tempsAtterDecol);

        void setTempsAntiCol(int _tempsAntiCol);

        void setTempsBoucleAttente(int _tempsBoucleAttente);
        //getteur
        std::string GetNom()const;

        int GetNombrePistes()const;
        int GetNbPlacesAuSol()const;
        int GetDelaiAttenteSol()const;
        int GetTempsAccesPiste()const;
        int GetTempsAtterDecol()const;

        int GetTempsAntiCol()const;
        int GetTempsBoucleAttente()const;

        void Afficher();

        void remplissageAvions();

        void aterrissage(int i, Type_avion plane);

        void decollage(int i, Type_avion plane);

        void fileTransitionSortie(Type_avion plane);
        void fileTransitionEntree(Type_avion plane);

        void zoneStockage(Type_avion plane);

        void zoneAttente(Type_avion plane);

        void defilerBoucleAttente();
        void defilerZoneStockage();

        void defilerTransSortie();

        void defilerTransEntree();

        void defilerPiste(int i);

};

auto comp = [](const std::pair<int, int> &a, const std::pair<int, int> &b){return a.second > b.second;};
auto comparaison = [](const std::pair<int, int> &tempSom, const std::pair<int, int> &tempLong) {return tempSom.second > tempLong.second;};

class Reseau_aerien
{
    private :
        std::vector<Aeroport> m_aeroports;
        std::vector<std::vector<std::pair<Aeroport, int>>> m_reseau_aerien;
        int m_taille; //taille de notre graphe
        int m_ordre; //ordre de notre graphe

    public :
        //R�cuperation des donn�es de notre r�seau a�rien
        Reseau_aerien();

        void chargementAeroports();

        void afficherAeroports();
        //Fonction qui retourne l'indice en fct du nom de l'aeroport
        int indAeroport(std::string nom);
        //Sous-programme pour trouver le plus court chemin
        int Dijkstra(int a1, int a2, std::vector<int> *predecesseurs,std::string type);
        void AffichagePCC();
        //Getters
        int GetOrdre()const;
        int GetTaille()const;
        std::vector<Aeroport> GetAeroports()const;
        std::vector<std::vector<std::pair<Aeroport, int>>> GetReseauAerien()const;
        //Setters
        void SetOrdre(int _ordre);
        void SetTaille(int _taille);
        void SetAeroports(std::vector<Aeroport> _aeroports);
        void SetReseauAerien(std::vector<std::vector<std::pair<Aeroport, int>>> _reseau_aerien);
};

class Vol
{
    private :
        Aeroport m_aero_dep;
        Aeroport m_aero_arr;
        std::vector<Aeroport> m_PCC;
        int m_indPCC;
        Type_avion m_avion;
        bool m_etat_av;
        bool m_fin;
        int m_Depx;
        int m_Depy;
        int m_Arx;
        int m_Ary;


    public :

        Vol();
        Vol(Aeroport aero_dep,Aeroport aero_arr,Type_avion avion);
        Type_avion Getavion()const;
        void etatav();
        void SetAvion(Type_avion av);
        Aeroport Getdep()const;
        Aeroport GetArr()const;
        std::vector<Aeroport> Get_PCC()const;
        void Set_PCC(std::vector<Aeroport> PCC);
        int Get_indPCC()const;
        void Set_indPCC(int PCC);
        int GetArx()const;
        int GetAry()const;
        void SetArx(int Arx);
        void SetAry(int Ary);
        int GetDepx();
        int GetDepy();
        bool GetEtat();
        bool GetFin();
        void Setdep(Aeroport vol);
        void SetArr(Aeroport vol);
        void SetEtat(bool _etat_av);
        void SetFin(bool _fin);
        void SetDepx(int x);
        void SetDepy(int y);

};

class Menu
{
    private:
        int m_choix;

    public:
        Menu();
        //Methode

        void initialisationAllegro();
        Vol repartitionDest(Reseau_aerien *reseau);
        float fctdroitey(float x1,float y1,float x2,float y2,float posx,float &a);
        float fctdroitex(float x1,float y1,float x2,float y2,float posy,float &a);
        void visualisation_graphique(Reseau_aerien *reseau);
        void deroulement();

};

#include "vol.cpp"
#include "menu.cpp"
#include "type_avion.cpp"
#include "aeroport.cpp"
#include "reseau_aerien.cpp"

#endif // HEADER_H_INCLUDED
