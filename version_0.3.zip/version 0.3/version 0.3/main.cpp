#include "header.h"

int main()
{
    //Initialisation();
    menu();
    //allegro_exit();
    return 0;

}END_OF_MAIN() ;

