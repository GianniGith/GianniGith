#include "header.h"

std::vector <Type_avion> Avions;
int stockage;
constexpr int MIN = 1;
constexpr int MAX = 3;

constexpr int RAND_NUMS_TO_GENERATE = stockage;

Aeroport::remplirVector(vector<Type_avion>&);

ifstream fichier("C:C:\Users\tompa\OneDrive\Bureau\Projet Piscine\version 0.3\version 0.3\aeroports.txt");  //Ouverture d'un fichier en lecture

 if(fichier)
   {

      string ligne; //Une variable pour stocker lignes lues

      while(getline(fichier, ligne))
      {
       if strcmp(ligne,"New York")==0
       {
           stockage = 12;
           remplirVector();
       }
       if strcmp(ligne,"Montreal")==0
       {
           stockage = 4;
       }
       if strcmp(ligne,"Londres")==0
       {
           stockage = 10;
       }
       if strcmp(ligne,"Perth")==0
       {
           stockage = 6;
       }
       if strcmp(ligne,"Bangkok")==0
       {
           stockage = 6;
       }
       if strcmp(ligne,"Dublin")==0
       {
           stockage = 5;
       }
        if strcmp(ligne,"Copenhague")==0
       {
           stockage = 12;
       }
       //Total de 55 avions ,court, moyen ou long courrier


      }
   }
   else
   {
      cout << "ERREUR: Impossible d'ouvrir le fichier en lecture." << endl;
   }

   void remplirVector(vector<Type_avion>& listeavions,stockage)
   {
       int nombreAvions;
       for(int i=0;i<stockage; i++)
       {


       }
   }
