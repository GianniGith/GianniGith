#include "header.h"


void menu()
{
    int choix;
    int compteur;
    std::vector<std::string> Information(TAILLE_FICHIER);
    std:: string Info;

    Aeroport *aeroport;
    Type_avion *Type;

    //Caracteristique des aeroports
    std::string Nom;
    int nombrePiste;
    int nombrePlaces;
    int DelaiAttente;
    int TempsAcces;
    int DureeAtterissage;
    int DureeDecollage;
    int DureeAntiCollision;
    int DureeBoucle;

    //Caracteristiques du type de l'avion
    std::string type;
    int cons;
    int carburant;

    //Ouverture du fichier

    std::string line;
    /*
    std::cout<<"Choisir le nom de l aeroport : "<<std::endl;
    std::cin >>Nom;
    std::cout<<"Choisir le nombre de piste : "<<std::endl;
    std::cin >>nombrePiste;
    std::cout<<"Quel est le delai d attente : "<<std::endl;
    std::cin >>DelaiAttente;
    std::cout<<"Quel est le temps d acces: "<<std::endl;
    std::cin >>TempsAcces;
    std::cout<<"Quel est la duree d atterissage: "<<std::endl;
    std::cin >>DureeAtterissage;
    std::cout<<"Quel est la duree du decollage : "<<std::endl;
    std::cin >>DureeDecollage;
    std::cout<<"Quel est la duree d anti collision "<<std::endl;
    std::cin >>DureeAntiCollision;
    std::cout<<"Quel est la duree de la boucle: "<<std::endl;
    std::cin >>DureeBoucle;

    aeroport = new Aeroport(Nom,nombrePiste,nombrePlaces,DelaiAttente,TempsAcces,DureeAtterissage,DureeDecollage,DureeAntiCollision,DureeBoucle);
    std::cout<<aeroport->GetNom()<<" "<<aeroport->GetNombrePiste() << " "<<aeroport->GetNombrePlace()<<aeroport->GetDelaiAttente()<<" "<<aeroport->GetTempsAcces() << " "<<aeroport->GetDureeAtterissage()<<aeroport->GetDureeDecollage()<<" "<<aeroport-> GetDureeAntiCollision()<<" "<<aeroport->GetDureeBoucle();

    std::cout <<"Choisir le type d avion : "<<std::endl;
    std::cin >> type;
    std::cout <<"Choisir la consommation de l avion : "<<std::endl;
    std::cin >> cons;
    std::cout <<"Choisir la quantite de carburant: "<<std::endl;
    std::cin >> carburant;

    Type = new Type_avion(type,cons,carburant);
    std::cout<<Type->GetType()<<" "<<Type->GetConsommation() << " "<<Type->GetCapaciteCarburant();

    */

    std::cout <<std::endl<<"1 - La Liste des aeroports et leurs types"<<std::endl;
    std::cout <<"3 -Visualiser graphiquement du reseau d aeroports"<<std::endl;
    std::cout <<"4 -Calculer le reseau de l arbre"<<std::endl;
    std::cout <<"5 -Afficher le reseau de l arbre"<<std::endl;
    std::cout <<"6 -Visualiser graphiquement le reseau de l arbre"<<std::endl;
    std::cout <<std::endl<<"Votre choix : "<<std::endl;
    std::cin>>choix;

switch(choix)
{
 case 1 :
    void ListeAeroports();
    //Afficher la liste des avions + differents types d'avion
     break;

 default :
    break;

    }


}

void ListeAeroports ()
{
ifstream MonFichier("C:\Users\tompa\OneDrive\Bureau\Projet Piscine\version 0.3\version 0.3\aeroports.txt");
    if(MonFichier)
        {
            fichier.open("aeroports.txt");
            for(int i=0;i<Information.size();i++)
            {
                std::getline(fichier,Information[i]);
                std::cout <<Information[i]<<std::endl;
            }
        }
        else
        {
            std::cerr <<"Erreur;;Imposssible d'ouvrir le fichier"<< std::endl;
        }
        fichier.close();
}
