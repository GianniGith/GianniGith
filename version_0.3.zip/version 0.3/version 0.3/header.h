#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#include <iostream>
#include <string.h>
#include <fstream>
#include <vector>
#include <sstream>
#include <allegro.h>
#define TAILLE_FICHIER 62
#include <random>

class Aeroport
{
    private:
        std::string m_nomAeroport;
        int m_nombre_piste;
        int m_nombre_places;
        int m_delai_attente;
        int m_temps_acces;
        int m_duree_atterissage;
        int m_duree_decollage;
        int m_duree_anti_collision;
        int m_duree_boucle;
        vector <Type_avion> AvionAero;

    public :

        Aeroport(std::string _nomAeroport, int _nombre_piste , int _nombre_places, int _delai_attente,int _temps_acces,int _duree_atterissage,int _duree_decollage,int _duree_anti_collision,int _duree_boucle)
        {
            m_nomAeroport =_nomAeroport;
            m_nombre_piste = _nombre_piste;
            m_nombre_places = _nombre_places;
            m_delai_attente = _delai_attente;
            m_temps_acces = _temps_acces;
            m_duree_atterissage = _duree_atterissage;
            m_duree_decollage = _duree_decollage;
            m_duree_anti_collision = _duree_anti_collision;
            m_duree_boucle = _duree_boucle;

        }

        //Getteur
        std::string GetNom()
        {
            return m_nomAeroport;
        }
        int GetNombrePiste()
        {
            return m_nombre_piste;
        }
        int GetNombrePlace()
        {
            return m_nombre_places;
        }
        int GetDelaiAttente()
        {
            return m_delai_attente;
        }
        int GetTempsAcces()
        {
            return m_temps_acces;
        }
        int GetDureeAtterissage()
        {
            return m_duree_atterissage;
        }
        int GetDureeDecollage()
        {
            return m_duree_decollage;
        }
        int GetDureeAntiCollision()
        {
            return m_duree_anti_collision;
        }
        int GetDureeBoucle()
        {
            return m_duree_boucle;
        }

        //Setteur
        void SetNomAeroport(std::string nomAeroport)
        {
            m_nomAeroport=nomAeroport;
        }
        void SetNombrePiste(int nombre_piste)
        {
            m_nombre_piste=nombre_piste;
        }
        void SetNombrePlace(int nombre_places)
        {
            m_nombre_places=nombre_places;
        }
        void SetDelaiAttente(int delai_attente)
        {
            m_delai_attente=delai_attente;
        }
        void SetTempsAcces(int temps_acces)
        {
            m_temps_acces=temps_acces;
        }
        void SetDureeAtterissage(int duree_atterissage)
        {
            m_duree_atterissage=duree_atterissage;
        }
        void SetDureeDecollage(int duree_decollage)
        {
            m_duree_decollage=m_duree_decollage;
        }
        void SetAtnicollision(int duree_anti_collision)
        {
            m_duree_anti_collision=duree_anti_collision;
        }
        void SetDureeBoucle(int duree_boucle)
        {
            m_duree_boucle=duree_boucle;
        }

};
class Type_avion
{
    private:
        std::string m_type;
        int m_consommation;
        int m_capacite_carburant;

    public:

        Type_avion(std::string _type,int _consommation,int _capacite_carburant)
        {
            m_type = _type;
            m_consommation = _consommation;
            m_capacite_carburant = _capacite_carburant;
        }
        //Getteur
        std::string GetType()
        {
            return m_type;
        }
        int GetConsommation()
        {
            return m_consommation;
        }
        int GetCapaciteCarburant()
        {
            return m_capacite_carburant;
        }

        //Setteur
        void SetType(int type)
        {
            m_type = type;
        }
        void SetConsommation(int conso)
        {
            m_consommation = conso;
        }
        void SetCapaciteCarburant(int capacite_carburant)
        {
            m_capacite_carburant = capacite_carburant;
        }

};
void menu();
void ListeAeroports ();
void Initialisation();
void visualisation_graphique();
#endif // HEADER_H_INCLUDED
