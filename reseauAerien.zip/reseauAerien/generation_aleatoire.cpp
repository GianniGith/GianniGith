#include "header.h"
int* remplissage_aleatoire()
{
    int taille_random = 3;
    std::ofstream file;
    int valeur[taille_random];

    srand((unsigned int)time(0));
    for(int i=0; i<3 ;i++)
    {
        valeur[i]=rand()%4;
        std::cout<<valeur[i];
    }
    return valeur;
}
void affichage_aleatoire()
{
    std::ofstream file;
    int *RemplissageAleatoire;

    RemplissageAleatoire=remplissage_aleatoire();

    for(int i=0;i<3;i++)
    {
        //std::cout<<*(RemplissageAleatoire+i);
    }
}
