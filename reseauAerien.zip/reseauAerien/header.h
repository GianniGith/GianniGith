#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#include <iostream>
#include <string.h>
#include <fstream>
#include <vector>
#include <sstream>
#include <allegro.h>
#include <random>
#define TAILLE_FICHIER 72
#define TAILLE_CARAC 10
void Initialisation();
void visualisation_graphique();
void ParametreAvion();
int* remplissage_aleatoire();
void affichage_aleatoire();
void ParametreAvion();

class Aeroport
{
    private:
        std::string m_nom;
        std::vector<std::string>TypAvion;
        int m_nombrePistes;
        int m_nbPlaceAuSol;
        int m_delaiAttenteSol;
        int m_tempsAccesPiste;
        int m_tempsAtterDecol;
        int m_tempsAntiCol;
        int m_tempsBoucleAttente;
        int liaisons;


    public:

        Aeroport()
        {
            std::string m_nom = "";
            m_nombrePistes = 0;
            m_nbPlaceAuSol = 0;
            m_delaiAttenteSol = 0;
            m_tempsAccesPiste = 0;
            m_tempsAtterDecol = 0;
            m_tempsAntiCol = 0;
            m_tempsBoucleAttente = 0;

        }

        void SetType(std::string Type)
        {
            TypAvion.push_back(Type);
        }
        void setNom(std::string _nom)
        {
            m_nom = _nom;
        }
        void setNombrePistes(int _nombrePistes)
        {
            m_nombrePistes = _nombrePistes;
        }

        void setNbPlacesAuSol(int _nbPlaceAuSol)
        {
            m_nbPlaceAuSol = _nbPlaceAuSol;
        }

        void setDelaiAttenteSol(int _delaiAttenteSol)
        {
            m_delaiAttenteSol = _delaiAttenteSol;
        }

        void setTempsAccesPiste(int _tempsAccesPiste)
        {
            m_tempsAccesPiste = _tempsAccesPiste;
        }

        void setTempsAtterDecol(int _tempsAtterDecol)
        {
            m_tempsAtterDecol = _tempsAtterDecol;
        }

        void setTempsAntiCol(int _tempsAntiCol)
        {
            m_tempsAntiCol = _tempsAntiCol;
        }

        void setTempsBoucleAttente(int _tempsBoucleAttente)
        {
            m_tempsBoucleAttente = _tempsBoucleAttente;
        }

        //Getteur
        int GetNbPlacesSol()
        {
            return m_nbPlaceAuSol;
        }

        void Afficher()
        {
            std::cout << "Nom de l'aeroport:  " << m_nom <<std::endl;
            std::cout << "Nombre de pistes:  " << m_nombrePistes << std::endl;
            std::cout << "Nombre de places au sol:  " << m_nbPlaceAuSol << std::endl;
            std::cout << "Delai d'attente au sol:  " << m_delaiAttenteSol <<std::endl;
            std::cout << "Temps d'acces au pistes:  " << m_tempsAccesPiste <<std::endl;
            std::cout << "Temps d'atterissage/decolage:  " << m_tempsAtterDecol <<std::endl;
            std::cout << "Temps d'anticollision:  " << m_tempsAntiCol <<std::endl;
            std::cout << "Temps en boucle d'attente:  " << m_tempsBoucleAttente <<std::endl;
            std::cout <<std::endl<<std::endl<<std::endl;
        }

};


class TousAeroports
{
    private:
        std::vector <Aeroport> m_tousAeroports;

    public:
        TousAeroports()
        {
            std::ifstream ifs{"donneesAero.txt"};
            for(int i = 0; i< 7; i++)
            {
                m_tousAeroports.push_back(Aeroport());


                if (!ifs) //Si probleme d'ouverture du ficher
                {
                throw std::runtime_error( "Impossible d'ouvrir en lecture donneesAero.txt" ); //Traitement et renvoi de l'erreur associee
                }

                std::string _nom;
                ifs>> _nom;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture nom");
                }
                m_tousAeroports[i].setNom(_nom);



                int _nbPistes;
                ifs>> _nbPistes;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture nbPlaceAuSol");
                }
                m_tousAeroports[i].setNombrePistes(_nbPistes);


                int _nbPlaceSol;
                ifs>> _nbPlaceSol;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture nbPlaceAuSol");
                }
                m_tousAeroports[i].setNbPlacesAuSol(_nbPlaceSol);


                int _delAtSol;
                ifs>> _delAtSol;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture delaiAttenteSol");
                }
                m_tousAeroports[i].setDelaiAttenteSol(_delAtSol);


                int _tempsAccesPiste;
                ifs>> _tempsAccesPiste;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture tempsAccesPiste");
                }
                m_tousAeroports[i].setTempsAccesPiste(_tempsAccesPiste);


                int _tempsAtterDecol;
                ifs>> _tempsAtterDecol;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture tempsAtterDecol");
                }
                m_tousAeroports[i].setTempsAtterDecol(_tempsAtterDecol);


                int _tempsAntiCol;
                ifs>> _tempsAntiCol;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture tempsAntiCol");
                }
                m_tousAeroports[i].setTempsAntiCol(_tempsAntiCol);


                int _tempsBoucleAttente;
                ifs>> _tempsBoucleAttente;
                if ( ifs.fail() ) //Si probleme de lecture de l'ordre
                {
                    throw std::runtime_error("Probleme lecture tempsBoucleAttente");
                }
                m_tousAeroports[i].setTempsBoucleAttente(_tempsBoucleAttente);
            }
        }

        void afficherTousAeroports()
        {
            for(int i = 0; i< 7 ; i++)
            {
                m_tousAeroports[i].Afficher();
            }
        }
};


class Type_avion
{
    private:
        std::string m_type;
        int m_consommation;
        int m_capacite_carburant;
        int m_capacite_carburant_actuel;
        int m_capacite_carburant_max;
        int m_altitude;
        int m_x;
        int m_y;
        std::vector<Aeroport> m_avion;
        int m_deplacement_x;
        int m_deplacement_y;

    public:

        Type_avion()
        {
            m_type = "";
            m_consommation = 0;
            m_capacite_carburant = 0;
        }
        //Getteur
        int GetX()
        {
            return m_x;
        }
        int GetY()
        {
            return m_y;
        }
        int GetdeplacementX()
        {
            return m_deplacement_x;
        }
        int GetdeplacementY()
        {
            return m_deplacement_y;
        }
        int GetCapaciteCarburantActuel()
        {
            return m_capacite_carburant_actuel;
        }
        int GetCapaciteCarburantMax()
        {
            return m_capacite_carburant_max;
        }
        int Getaltitude()
        {
            return m_altitude;
        }
        std::string GetType()
        {
            return m_type;
        }
        int GetConsommation()
        {
            return m_consommation;
        }
        int GetCapaciteCarburant()
        {
            return m_capacite_carburant;
        }
        std::vector<Aeroport> GetAvion()
        {
            return m_avion;
        }

        //Setteur
        void SetType(std::string _type)
        {
            m_type = _type;
        }
        void SetConsommation(int _conso)
        {
            m_consommation = _conso;
        }
        void SetCapaciteCarburant(int _capacite_carburant)
        {
            m_capacite_carburant = _capacite_carburant;
        }
        void SetCapaciteCarburantActuel(int _capacite_carburant_max)
        {
            m_capacite_carburant_max = _capacite_carburant_max;
        }
        void SetCapaciteCarburantMax(int _capacite_carburant_actuel)
        {
            m_capacite_carburant_actuel = _capacite_carburant_actuel;
        }
        void SetAltitude(int _altitude)
        {
            m_altitude = _altitude;
        }
        void SetX(int _x)
        {
            m_x = _x;
        }
        void SetY(int _y)
        {
            m_y = _y;
        }
        void SetDeplacementX(int _deplacement_x)
        {
            m_deplacement_x = _deplacement_x;
        }
        void SetDeplacementY(int _deplacement_y)
        {
            m_deplacement_y = _deplacement_y;
        }

};
class Menu
{
    private:
        int choix;
        std::vector<std::string> Information[TAILLE_FICHIER];

    public:
        Menu()
        {
            //rien a faire
        }
        //Methode
        void menuto()
        {
            int choix;
            std::cout <<std::endl<<"1 - La Liste des aeroports et leurs types"<<std::endl;
            std::cout <<"2 -Calculer et Afficher le reseau de l arbre"<<std::endl;
            std::cout <<"3 -Afficher le chemin le plus court de l arbre "<<std::endl;
            std::cout <<"4 -Arreter le programme"<<std::endl;

            do
            {
                std::cout <<"Quel est votre choix :";
                std::cin >>choix;

            }while(choix>4 || choix<0);


            switch(choix)
            {
                case 1 :
                {
                    TousAeroports reseau = TousAeroports();
                    reseau.afficherTousAeroports();
                    break;
                }

                case 2:
                {
                    Initialisation();
                    visualisation_graphique();
                    break;
                }
                case 3:
                    //Afficher le chemin le plus court
                    break;
                case 4:
                    //allegro.exit();
                    break;
            }
        }
};

#endif // HEADER_H_INCLUDED
