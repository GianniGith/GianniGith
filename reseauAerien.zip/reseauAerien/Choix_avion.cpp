#include "header.h"

void ParametreAvion()
{
    int aleatoire;
    std::string type;
    Type_avion AvionChoix;
    TousAeroports aero;

    srand(time(NULL));
    aleatoire=rand()%3+1;

    switch(aleatoire)
    {
        case 1:
            type ="court";
            AvionChoix.SetType(type);
            break;
        case 2:
             type="moyen";
             AvionChoix.SetType(type);
            break;
        case 3:
             type="long";
             AvionChoix.SetType(type);
            break;
    }
    std::cout<<AvionChoix.GetType();

    for(int i=0;i<7;i++)
    {
        for(int j=0;j<aero[i].GetNbPlacesSol();j++)
        {
            aero[j].push_back(AvionChoix);
        }
    }
}

