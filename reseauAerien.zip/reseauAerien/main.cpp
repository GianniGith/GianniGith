#include "header.h"

int main()
{
    ParametreAvion();
    /*
    Menu menuu = Menu();
    menuu.menuto();
    allegro_exit();*/
    return 0;

}END_OF_MAIN() ;

