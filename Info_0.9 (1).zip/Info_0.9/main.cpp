#include "header.h"

int main()
{
    srand(time(nullptr));

    Menu nouveau;
    nouveau.deroulement();
    allegro_exit();
    return 0;

}END_OF_MAIN() ;
