#include "header.h"

Menu::Menu()
{

}

void Menu::deroulement()
{
    Reseau_aerien reseau;
    std::cout <<std::endl<<"1 - La Liste des aeroports et leurs types"<<std::endl;
    std::cout <<"2 -Afficher le reseau de l arbre"<<std::endl;
    std::cout <<"3 -Afficher le chemin le plus court de l arbre"<<std::endl;
    std::cout <<"4 -Arreter le programme"<<std::endl;

    do
    {
        do
        {
            std::cout <<"Quel est votre choix :";
            fflush(stdin);
            std::cin >>m_choix;

        }while(m_choix != '1' &&  m_choix != '2' &&  m_choix != '3' &&  m_choix != '4');

        switch(m_choix)
        {
            case '1' :
            {
                reseau.afficherAeroports();
                break;
            }

            case '2':
            {
                initialisationAllegro();
                visualisation_graphique(&reseau);
                allegro_exit();
                break;
            }
            case '3':
            {
                 //Afficher le chemin le plus court
                reseau.AffichagePCC();
                break;
            }

            case '4':
                //allegro.exit();
                break;
        }
    }while(m_choix!='4');

}

void Menu::initialisationAllegro()
{

    allegro_init();
    install_keyboard();
    install_timer();
    install_mouse();

    set_color_depth(desktop_color_depth());


}

float Menu::fctdroitey(float x1,float y1,float x2,float y2,float posx,float &a)
{
    float posy;
    a=(y2-y1)/(x2-x1);
    float b=y1-a*x1;
    posy=abs((a*posx+b));
    return posy;
}

float Menu::fctdroitex(float x1,float y1,float x2,float y2,float posy,float &a)
{
    float posx;
    a=(float)((y2-y1)/(x2-x1));
    float b=y1-(a*x1);
    posx=abs((posy-b)/a);

    return posx;
}

Vol Menu::repartitionDest(Reseau_aerien *reseau, int aero)
{
    Vol vol;
    int rand1,rand2;
    Aeroport temp;
    std::vector<Aeroport> temp2;
    //std::queue<Type_avion> ajoutpiste;
    //std::pair<std::queue<Type_avion>,std::string> piste;
    //std::vector<std::pair<std::queue<Type_avion>,std::string>> reset_piste;
    std::vector<Type_avion> test2;
    Type_avion test;
    int NYx=553,NYy=353,BAx=1453,BAy=573,BRx=691,BRy=695,TOx=1611,TOy=420,ALx=971,ALy=517,LOx=906,LOy=321,SYx=1525,SYy=820;
    //On initialisa aleatoirement l'aerop de depart et d'arriv�e
    do
    {
        rand1=rand()%7;
    }while(reseau->GetAeroports().at(rand1).GetPlaceUtilise()==reseau->GetAeroports().at(rand1).GetNbPlacesAuSol());//on blinde pour que les avions ne puissent pas aller a un endroit ou il n'y a pas la place


    do
    {
        rand2=rand()%7;

    }while(aero==rand2 /*&& reseau->GetAeroports().at(rand2).GetPlaceUtilise()==reseau->GetAeroports().at(rand2).GetNbPlacesAuSol()*/);//on blinde pour que les avions ne puissent pas aller a un endroit ou il n'y a pas la place
    //temp2.SetStockAvions();
    for(int i=0;i<(int)reseau->GetAeroports().size();i++)
    {
        temp2.push_back(reseau->GetAeroports().at(i));
    }
    temp=temp2[aero];
    for(int i=0;i<(int)temp.GetStockAvions().size();i++)
    {
        test2.push_back(temp.GetStockAvions().at(i));
    }
    test=test2.front();
    test.SetDeplacementX(0.7);
    test.SetDeplacementY(0.7);
    //vol.SetAvion(test);
    test2.pop_back();
    /*x=(float)vol.GetDepx();
    y=(float)vol.GetDepy();
    test.SetX(x);
    test.SetY(y);*/
    temp.SetStockAvions(test2);
    //vol.SetAvion(test);
    //on donne un avion et une arriv�e � l'avion qui va partir
    if(reseau->GetAeroports().at(aero).GetNom()=="New-York" && reseau->GetAeroports().at(aero).GetPlaceUtilise()!=reseau->GetAeroports().at(aero).GetNbPlacesAuSol())
    {
        vol.Setdep(reseau->GetAeroports().at(aero));
        vol.SetDepx(NYx);
        vol.SetDepy(NYy);
        temp.setPlaceUtilise(temp.GetPlaceUtilise()+1);
        temp2[aero]=temp;
        reseau->SetAeroports(temp2);
    }
    if(reseau->GetAeroports().at(aero).GetNom()=="Alger" && reseau->GetAeroports().at(aero).GetPlaceUtilise()!=reseau->GetAeroports().at(aero).GetNbPlacesAuSol())
    {
        vol.Setdep(reseau->GetAeroports().at(aero));
        vol.SetDepx(ALx);
        vol.SetDepy(ALy);
        temp.setPlaceUtilise(temp.GetPlaceUtilise()+1);
        temp2[aero]=temp;
        reseau->SetAeroports(temp2);
    }
    if(reseau->GetAeroports().at(aero).GetNom()=="Tokyo" && reseau->GetAeroports().at(aero).GetPlaceUtilise()!=reseau->GetAeroports().at(aero).GetNbPlacesAuSol())
    {
        vol.Setdep(reseau->GetAeroports().at(aero));
        vol.SetDepx(TOx);
        vol.SetDepy(TOy);
        temp.setPlaceUtilise(temp.GetPlaceUtilise()+1);
        temp2[aero]=temp;
        reseau->SetAeroports(temp2);
    }
    if(reseau->GetAeroports().at(aero).GetNom()=="Sydney" && reseau->GetAeroports().at(aero).GetPlaceUtilise()!=reseau->GetAeroports().at(aero).GetNbPlacesAuSol())
    {
        vol.Setdep(reseau->GetAeroports().at(aero));
        vol.SetDepx(SYx);
        vol.SetDepy(SYy);
        temp.setPlaceUtilise(temp.GetPlaceUtilise()+1);
        temp2[aero]=temp;
        reseau->SetAeroports(temp2);
    }
    if(reseau->GetAeroports().at(aero).GetNom()=="Londres" && reseau->GetAeroports().at(aero).GetPlaceUtilise()!=reseau->GetAeroports().at(aero).GetNbPlacesAuSol())
    {
        vol.Setdep(reseau->GetAeroports().at(aero));
        vol.SetDepx(LOx);
        vol.SetDepy(LOy);
        temp.setPlaceUtilise(temp.GetPlaceUtilise()+1);
        temp2[aero]=temp;
        reseau->SetAeroports(temp2);
    }
    if(reseau->GetAeroports().at(aero).GetNom()=="Bangkok" && reseau->GetAeroports().at(aero).GetPlaceUtilise()!=reseau->GetAeroports().at(aero).GetNbPlacesAuSol())
    {
        vol.Setdep(reseau->GetAeroports().at(aero));
        vol.SetDepx(BAx);
        vol.SetDepy(BAy);
        temp.setPlaceUtilise(temp.GetPlaceUtilise()+1);
        temp2[aero]=temp;
        reseau->SetAeroports(temp2);
    }
    if(reseau->GetAeroports().at(aero).GetNom()=="Brasilia" && reseau->GetAeroports().at(aero).GetPlaceUtilise()!=reseau->GetAeroports().at(aero).GetNbPlacesAuSol())
    {
        vol.Setdep(reseau->GetAeroports().at(aero));
        vol.SetDepx(BRx);
        vol.SetDepy(BRy);
        temp.setPlaceUtilise(temp.GetPlaceUtilise()+1);
        temp2[aero]=temp;
        reseau->SetAeroports(temp2);
    }
    test.SetDeplacementX(0.7);
    test.SetDeplacementY(0.7);
    test.SetX(vol.GetDepx());
    test.SetY(vol.GetDepy());
    //la mm avec arrivee
    /*for(int i=0;i<reseau->GetAeroports().size();i++)
    {
        temp2.push_back(reseau->GetAeroports().at(i));
    }
    std::cout<<"av temp\n";
    temp.Setpistes(temp2.at(rand2).Getpistes());
    std::cout<<"ap temp\n";
    //On dit a l'aeroport d'arrivee qu'il va recevoir
    for(int i=0;i<temp.Getpistes().size();i++)
    {
        reset_piste.push_back(temp.Getpistes().at(i));
    }
    std::cout<<"reset piste"<<reset_piste.size()<<"\n";
    do
    {
        rand1=rand()%(reset_piste.size());
        std::cout<<"rand1 \n";
    }while(reset_piste[rand1].second!="libre");
    std::cout<<"avant piste"<<"\n";
    ajoutpiste.push(vol.Getavion());
    std::cout<<"avpair"<<vol.Getavion().GetType()<<"\n";
    piste=std::make_pair(ajoutpiste,"atterissage");

    std::cout<<"prout"<<vol.Getavion().GetType()<<"\n";
    temp.setPlaceUtilise(temp.GetPlaceUtilise()+1);
    std::cout<<"pl util\n";
    temp.fileTransitionEntree(vol.Getavion());
    std::cout<<"ap fileentree\n";
    temp.aterrissage(0,vol.Getavion());
    std::cout<<"ap atter\n";
    temp2[rand2]=temp;
    std::cout<<"ap temp2\n";
    reseau->SetAeroports(temp2);
    std::cout<<"reseau\n";
    */
    if(reseau->GetAeroports().at(rand2).GetNom()=="New-York" && reseau->GetAeroports().at(rand2).GetPlaceUtilise()!=reseau->GetAeroports().at(rand2).GetNbPlacesAuSol())
    {
        vol.SetArr(reseau->GetAeroports().at(rand2));
        vol.SetArx(NYx);
        vol.SetAry(NYy);
    }
    if(reseau->GetAeroports().at(rand2).GetNom()=="Alger" && reseau->GetAeroports().at(rand2).GetPlaceUtilise()!=reseau->GetAeroports().at(rand2).GetNbPlacesAuSol())
    {
        vol.SetArr(reseau->GetAeroports().at(rand2));
        vol.SetArx(ALx);
        vol.SetAry(ALy);
    }
    if(reseau->GetAeroports().at(rand2).GetNom()=="Tokyo" && reseau->GetAeroports().at(rand2).GetPlaceUtilise()!=reseau->GetAeroports().at(rand2).GetNbPlacesAuSol())
    {
        vol.SetArr(reseau->GetAeroports().at(rand2));
        vol.SetArx(TOx);
        vol.SetAry(TOy);
    }
    if(reseau->GetAeroports().at(rand2).GetNom()=="Sydney" &&   reseau->GetAeroports().at(rand2).GetPlaceUtilise()!=reseau->GetAeroports().at(rand2).GetNbPlacesAuSol())
    {
        vol.SetArr(reseau->GetAeroports().at(rand2));
        vol.SetArx(SYx);
        vol.SetAry(SYy);
    }
    if(reseau->GetAeroports().at(rand2).GetNom()=="Londres" && reseau->GetAeroports().at(rand2).GetPlaceUtilise()!=reseau->GetAeroports().at(rand2).GetNbPlacesAuSol())
    {
        vol.SetArr(reseau->GetAeroports().at(rand2));
        vol.SetArx(LOx);
        vol.SetAry(LOy);
    }
    if(reseau->GetAeroports().at(rand2).GetNom()=="Bangkok" && reseau->GetAeroports().at(rand2).GetPlaceUtilise()!=reseau->GetAeroports().at(rand2).GetNbPlacesAuSol())
    {
        vol.SetArr(reseau->GetAeroports().at(rand2));
        vol.SetArx(BAx);
        vol.SetAry(BAy);
    }
    if(reseau->GetAeroports().at(rand2).GetNom()=="Brasilia" && reseau->GetAeroports().at(rand2).GetPlaceUtilise()!=reseau->GetAeroports().at(rand2).GetNbPlacesAuSol())
    {
        vol.SetArr(reseau->GetAeroports().at(rand2));
        vol.SetArx(BRx);
        vol.SetAry(BRy);
    }
    vol.SetAvion(test);
    std::cout<<"vol type avion"<<vol.Getdep().GetNom()<<"dep coord"<<vol.GetDepx()<<" : "<<vol.GetDepy()<<"\n";
    vol.etatav();
    return vol;
}

void Menu::visualisation_graphique(Reseau_aerien * reseau)
{
    std::vector<Vol> plan_de_vol;
    std::string A1, type;
    std::vector<std::pair<int,std::vector<int>>> listePrede (7);
    std::vector<int>::iterator it;
    Vol vol;
    Type_avion av;

    float x,y,coeff;

    for(int i=0;i<7;i++)
    {
        vol=repartitionDest(reseau, i);
        plan_de_vol.push_back(vol);

        //std::cout<<"preimp  pdv"<<i+1<< "depart : "<<plan_de_vol.at(i).Getavion().GetX()<<" arrivee : "<<plan_de_vol.at(i).Getavion().GetY()<<"\n";
    }

    do
    {
        std::cout<<"\nSAISIR LE NOM DE L'AEROPORT DE DEPART : "<<std::endl;
        std::cin>>A1;
    }while(A1 != "New-York" && A1 != "Londres" && A1 != "Brasilia" && A1 != "Alger" && A1 != "Tokyo" && A1 != "Sydney" && A1 != "Bangkok");

    do
    {
        std::cout<<"\nSAISIR LE TYPE D'AVION : court/moyen/long"<<std::endl;
        std::cin>>type;
    }while(type!="court" && type !="moyen" && type!="long");

    for (int i = 0; i< reseau->GetOrdre(); i++)
    {
        listePrede[i].first = reseau->Dijkstra(reseau->indAeroport(A1),i, &listePrede[i].second,type);
        std::cout << "Chemin permettant d'aller de " << A1 << " a " << reseau->GetAeroports()[i].GetNom() << " :" << std::endl;

        if(listePrede[i].first<45000){
            std::cout<<"" <<reseau->GetAeroports()[*listePrede[i].second.begin()].GetNom();
        }else{
            std::cout<<"Pas de chemin possible pour un avion de type "<<type;
        }

        for (it = listePrede[i].second.begin()+1; it!=listePrede[i].second.end(); it++)
        {

            std::cout<< "-->" << reseau->GetAeroports()[*it].GetNom();
        }

        if(listePrede[i].first>45000)
        {
            listePrede[i].first = 0;
        }
        std::cout <<std::endl << "Distance entre " << A1 << " et " << reseau->GetAeroports()[i].GetNom() << " :" << listePrede[i].first <<" kilometres"<< std::endl<< std::endl;

    }





    if(set_gfx_mode(GFX_AUTODETECT_FULLSCREEN,1920,1080,0,0)!=0)
    {
        allegro_message("Probleme de mode graphique");
        allegro_exit();
        exit(EXIT_FAILURE);
    }


    BITMAP *Carte;
    BITMAP *Infos;
    BITMAP *buffer1;
    BITMAP *longcourrier[7];
    BITMAP *moyen;
    BITMAP *court;
    BITMAP *start;

    moyen= load_bitmap("moyen.bmp",NULL);
    court= load_bitmap("court.bmp",NULL);
    Carte= load_bitmap("carte.bmp",NULL);
    Infos= load_bitmap("infos.bmp",NULL);
    start= load_bitmap("start.bmp",NULL);

    bool starting = false;

    for (int i = 0; i< reseau->GetOrdre(); i++)
    {
        if(listePrede[i].first<45000){
            std::cout<<"" <<reseau->GetAeroports()[*listePrede[i].second.begin()].GetNom(); /// Premier elem
        }

        for (it = listePrede[i].second.begin()+1; it!=listePrede[i].second.end(); it++)
        {
            line(Carte,reseau->GetAeroports()[*(it-1)].GetPosX(),reseau->GetAeroports()[*(it-1)].GetPosY(),reseau->GetAeroports()[*it].GetPosX(),reseau->GetAeroports()[*it].GetPosY(), makecol(255,0,0));
            std::cout<< "-->" << reseau->GetAeroports()[*(it-1)].GetPosX() <<":" << reseau->GetAeroports()[*(it-1)].GetPosY();

        }

        if(listePrede[i].first>45000)
        {
            listePrede[i].first = 0;
        }
        std::cout <<std::endl << "Distance entre " << A1 << " et " << reseau->GetAeroports()[i].GetNom() << " :" << listePrede[i].first <<" kilometres"<< std::endl<< std::endl;

    }


    buffer1=create_bitmap(SCREEN_W,SCREEN_H);

    for(int i=0;i<7;i++)
    {
        av.SetType(plan_de_vol.at(i).Getavion().GetType());
        if(av.GetType() == "court")
        {
            longcourrier[i]= load_bitmap("court.bmp",NULL);
        }
        else if(av.GetType() == "moyen")
        {
            longcourrier[i]= load_bitmap("moyen.bmp",NULL);
        }
        if(av.GetType() == "long")
        {
            longcourrier[i]= load_bitmap("long.bmp",NULL);
        }


        av.SetDeplacementX(plan_de_vol.at(i).Getavion().GetdeplacementX());
        av.SetDeplacementY(plan_de_vol.at(i).Getavion().GetdeplacementY());
        av.SetX(plan_de_vol.at(i).Getavion().GetX());
        av.SetY(plan_de_vol.at(i).Getavion().GetY());
        //std::cout<<"preimp av"<<i+1<< "depart : "<<av.GetX()<<" arrivee : "<<av.GetY()<<"\n";
        x=(float)fctdroitex(plan_de_vol[i].GetDepx(),plan_de_vol[i].GetDepy(),plan_de_vol[i].GetArx(),plan_de_vol[i].GetAry(),av.GetY(),coeff);
        y=(float)fctdroitey(plan_de_vol[i].GetDepx(),plan_de_vol[i].GetDepy(),plan_de_vol[i].GetArx(),plan_de_vol[i].GetAry(),av.GetX(),coeff);
        if(abs(coeff)<0.3)av.SetDeplacementX(0.5);
        if(abs(coeff)<0.3)av.SetDeplacementY(0.5);
        if(abs(coeff)<0.1)av.SetDeplacementX(0.4);
        if(abs(coeff)<0.1)av.SetDeplacementY(0.4);
        if(abs(coeff)>0.3 && abs(coeff)<0.8)av.SetDeplacementX(0.8);
        if(abs(coeff)>0.3 && abs(coeff)<0.8)av.SetDeplacementY(0.8);
        if(abs(coeff)>2 && abs(coeff)<3)av.SetDeplacementX(0.65);
        if(abs(coeff)>2 && abs(coeff)<3)av.SetDeplacementY(0.65);
        if(abs(coeff)>=3)av.SetDeplacementX(0.55);
        if(abs(coeff)>=3)av.SetDeplacementY(0.55);
        if(plan_de_vol[i].GetAry()-plan_de_vol[i].GetDepy()<0)
        {
            y=-plan_de_vol[i].Getavion().GetdeplacementY();
            av.SetDeplacementY(y);
        }
        if(plan_de_vol[i].GetArx()-plan_de_vol[i].GetDepx()<0)
        {
            x=-plan_de_vol[i].Getavion().GetdeplacementX();
            av.SetDeplacementX(x);
        }
        plan_de_vol[i].SetAvion(av);

    }
    clear_bitmap(buffer1);
    //Determination des nouvelles positions
    blit(Carte,buffer1,0,0, (SCREEN_W-Carte->w)/2, (SCREEN_H-Carte->h)/2, Carte->w, Carte->h);
    show_mouse(buffer1);
    blit(buffer1,screen,0,0,0,0, buffer1->w, buffer1->h);
    while(!key[KEY_ESC])
    {

            while(starting == false)
            {
                if((mouse_b & 1) && mouse_x>=1741 && mouse_x<=1885 && mouse_y>=23 && mouse_y<=61)
                {
                    masked_blit(start,buffer1,0,0, (SCREEN_W-start->w)/2, (SCREEN_H-start->h)/2, start->w, start->h);
                    starting = true;
                }
                blit(buffer1,screen,0,0,0,0, buffer1->w, buffer1->h);
            }
            clear_bitmap(buffer1);
            //Determination des nouvelles positions
            blit(Carte,buffer1,0,0, (SCREEN_W-Carte->w)/2, (SCREEN_H-Carte->h)/2, Carte->w, Carte->h);
            for(int i=0;i<7;i++)
            {
                av.SetX(plan_de_vol[i].Getavion().GetX());
                av.SetY(plan_de_vol[i].Getavion().GetY());
                av.SetDeplacementX(plan_de_vol[i].Getavion().GetdeplacementX());
                av.SetDeplacementY(plan_de_vol[i].Getavion().GetdeplacementY());
                x=(float)fctdroitex(plan_de_vol[i].GetDepx(),plan_de_vol[i].GetDepy(),plan_de_vol[i].GetArx(),plan_de_vol[i].GetAry(),plan_de_vol[i].Getavion().GetY(),coeff);
                y=(float)fctdroitey(plan_de_vol[i].GetDepx(),plan_de_vol[i].GetDepy(),plan_de_vol[i].GetArx(),plan_de_vol[i].GetAry(),plan_de_vol[i].Getavion().GetX(),coeff);

                av.SetX(x+av.GetdeplacementX());
                av.SetY(y+av.GetdeplacementY());
                plan_de_vol[i].SetAvion(av);

                if(plan_de_vol[i].GetArx()-plan_de_vol[i].GetDepx()>0)
                {
                    if((int)(plan_de_vol[i].Getavion().GetX())>plan_de_vol[i].GetArx())plan_de_vol[i].SetFin(true);

                }
                if(plan_de_vol[i].GetArx()-plan_de_vol[i].GetDepx()<0)
                {
                    if((int)(plan_de_vol[i].Getavion().GetX())<plan_de_vol[i].GetArx())plan_de_vol[i].SetFin(true);

                }
                if(plan_de_vol[i].GetAry()-plan_de_vol[i].GetDepy()>0)
                {
                    if((int)(plan_de_vol[i].Getavion().GetY())>plan_de_vol[i].GetAry())plan_de_vol[i].SetFin(true);

                }
                if(plan_de_vol[i].GetAry()-plan_de_vol[i].GetDepy()<0)
                {
                    if((int)(plan_de_vol[i].Getavion().GetY())<plan_de_vol[i].GetAry())plan_de_vol[i].SetFin(true);

                }

                if(plan_de_vol[i].GetEtat()==true && plan_de_vol[i].GetFin()==false)
                {
                    std::cout<<"av "<<i<<"affochage"<<std::endl;
                    draw_sprite(buffer1,longcourrier[i],(int)(plan_de_vol[i].Getavion().GetX()-longcourrier[i]->w),(int)(plan_de_vol[i].Getavion().GetY()-longcourrier[i]->h));
                }
                else if(plan_de_vol[i].GetEtat()==false && plan_de_vol[i].GetFin()==false)
                {
                    std::cout<<"av "<<i<<"affochage"<<std::endl;
                    draw_sprite_h_flip(buffer1,longcourrier[i],(int)plan_de_vol[i].Getavion().GetX()-longcourrier[i]->w,(int)plan_de_vol[i].Getavion().GetY()-longcourrier[i]->h);
                }
            }

            show_mouse(buffer1);
            if(key[KEY_SPACE])
            {
                while(key[KEY_SPACE])
                {
                 masked_blit(Infos,screen,0,0, (SCREEN_W-Infos->w)/2, (SCREEN_H-Infos->h)/2, Infos->w, Infos->h);

                }

            }

           //masked_blit(court,screen,0,0, (SCREEN_W-court->w)/2, (SCREEN_H-court->h)/2, court->w, court->h);
            //masked_blit(moyen,screen,0,0, (SCREEN_W-moyen->w)/2, (SCREEN_H-moyen->h)/2, moyen->w, moyen->h);
           textprintf_ex(buffer1, font, 0, 20, makecol(0, 255, 255),-1, "x : %d , y : %d", mouse_x, mouse_y);


            blit(buffer1,screen,0,0,0,0, buffer1->w, buffer1->h);
            rest(20) ;
    }
    for(int i=0;i<7;i++)
    {
         destroy_bitmap(longcourrier[i]);
    }

    destroy_bitmap(Carte);
    destroy_bitmap(Infos);
    destroy_bitmap(start);

    destroy_bitmap(moyen);
    destroy_bitmap(court);

}


