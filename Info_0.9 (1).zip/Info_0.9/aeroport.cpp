#include "header.h"

Aeroport::Aeroport()
{
    std::string m_nom = "";
    m_nombrePistes = 0;
    m_nbPlaceAuSol = 0;
    m_delaiAttenteSol = 0;
    m_tempsAccesPiste = 0;
    m_tempsAtterDecol = 0;
    m_tempsAntiCol = 0;
    m_tempsBoucleAttente = 0;
    for (int i = 0; i <m_nombrePistes; i++)
    {
        m_piste[i].second = "libre";
    }

}



void  Aeroport::Setpistes(std::vector<std::pair<std::queue<Type_avion>,std::string>> _pistes)
{
    m_piste=_pistes;
}
std::vector<std::pair<std::queue<Type_avion>,std::string>> Aeroport::Getpistes()const
{
    return m_piste;
}
void Aeroport::SetType(Type_avion Type)
{
    m_stockAvions.push_back(Type);
}

void Aeroport::setPosX(int _posX)
{
    m_posX = _posX;
}

void Aeroport::setPosY(int _posY)
{
    m_posY = _posY;
}

void Aeroport::setNom(std::string _nom)
{
    m_nom = _nom;
}

void Aeroport::setNombrePistes(int _nombrePistes)
{
    m_nombrePistes = _nombrePistes;
}

void Aeroport::setNbPlacesAuSol(int _nbPlaceAuSol)
{
    m_nbPlaceAuSol = _nbPlaceAuSol;
}

void Aeroport::setDelaiAttenteSol(int _delaiAttenteSol)
{
    m_delaiAttenteSol = _delaiAttenteSol;
}

void Aeroport::setTempsAccesPiste(int _tempsAccesPiste)
{
    m_tempsAccesPiste = _tempsAccesPiste;
}

void Aeroport::setTempsAtterDecol(int _tempsAtterDecol)
{
    m_tempsAtterDecol = _tempsAtterDecol;
}

void Aeroport::setTempsAntiCol(int _tempsAntiCol)
{
    m_tempsAntiCol = _tempsAntiCol;
}

void Aeroport::setTempsBoucleAttente(int _tempsBoucleAttente)
{
    m_tempsBoucleAttente = _tempsBoucleAttente;
}

std::string Aeroport::GetNom()const
{
    return m_nom;
}

int Aeroport::GetPosX() const
{
    return m_posX;
}

int Aeroport::GetPosY() const
{
    return m_posY;
}

int Aeroport::GetNombrePistes()const
{
    return m_nombrePistes;
}

int Aeroport::GetNbPlacesAuSol()const
{
    return m_nbPlaceAuSol;
}

int Aeroport::GetDelaiAttenteSol()const
{
    return m_delaiAttenteSol;
}

int Aeroport::GetTempsAccesPiste()const
{
    return m_tempsAccesPiste;
}

int Aeroport::GetTempsAtterDecol()const
{
    return m_tempsAtterDecol;
}

void Aeroport::setPlaceUtilise(int _placeUtilise)
{
    m_placeUtilise=_placeUtilise;
}
int Aeroport::GetPlaceUtilise()const
{
    return m_placeUtilise;
}
int Aeroport::GetTempsAntiCol()const
{
    return m_tempsAntiCol;
}

std::vector<Type_avion> Aeroport::GetStockAvions()const
{
    return m_stockAvions;
}
void Aeroport::SetStockAvions(std::vector<Type_avion> _stock)
{
    m_stockAvions=_stock;
}
int Aeroport::GetTempsBoucleAttente()const
{
    return m_tempsBoucleAttente;
}

void Aeroport::Afficher()
{
    std::cout << "Nom de l'aeroport:  " << m_nom <<std::endl;
    std::cout << "Nombre de pistes:  " << m_nombrePistes << std::endl;
    std::cout << "Nombre de places au sol:  " << m_nbPlaceAuSol << std::endl;
    std::cout << "Delai d'attente au sol:  " << m_delaiAttenteSol <<std::endl;
    std::cout << "Temps d'acces au pistes:  " << m_tempsAccesPiste <<std::endl;
    std::cout << "Temps d'atterissage/decolage:  " << m_tempsAtterDecol <<std::endl;
    std::cout << "Temps d'anticollision:  " << m_tempsAntiCol <<std::endl;
    std::cout << "Temps en boucle d'attente:  " << m_tempsBoucleAttente <<std::endl;
    std::cout << "Position en X:  " << m_posX <<std::endl;
    std::cout << "Position en Y:  " << m_posY <<std::endl;
    std::cout <<std::endl<<std::endl<<std::endl;
    for(int j = 0; j<m_nbPlaceAuSol;j++)
    {
        std::cout<< "Avion"<<std::endl;
        std::cout<<"Type :" <<m_stockAvions[j].GetType()<<std::endl;
        std::cout<<"Capacite carburant :"<< m_stockAvions[j].GetCapaciteCarburant()<<std::endl;
        std::cout<<"Consommation :"<< m_stockAvions[j].GetConsommation()<<std::endl<<std::endl<<std::endl;
    }
}

void Aeroport::remplissageAvions()
{
    std::ifstream ifs1{"Parametre avion_long.txt"};
    std::ifstream ifs2{"Parametre avion_moyen.txt"};
    std::ifstream ifs3{"Parametre avion_court.txt"};

    std::string _type;
    int _consommation;
    int _capacite;

    for (int i =0; i< m_nbPlaceAuSol; i++)
    {
        m_stockAvions.push_back(Type_avion());
        int alea = rand()%3;

        switch (alea)
        {
                case 0:
                {
                    ifs1>> _type;
                    ifs1>> _consommation;
                    ifs1>> _capacite;

                    m_stockAvions[i].SetType(_type);
                    m_stockAvions[i].SetConsommation(_consommation);
                    m_stockAvions[i].SetCapaciteCarburant(_capacite);
                    break;
                }

                case 1:
                {
                    ifs2>> _type;
                    ifs2>> _consommation;
                    ifs2>> _capacite;

                    m_stockAvions[i].SetType(_type);
                    m_stockAvions[i].SetConsommation(_consommation);
                    m_stockAvions[i].SetCapaciteCarburant(_capacite);
                    break;
                }

                case 2:
                {
                    ifs3>> _type;
                    ifs3>> _consommation;
                    ifs3>> _capacite;

                    m_stockAvions[i].SetType(_type);
                    m_stockAvions[i].SetConsommation(_consommation);
                    m_stockAvions[i].SetCapaciteCarburant(_capacite);
                    break;
                }
        }
    }
}

void Aeroport::aterrissage(int i, Type_avion plane)
{
    for(int j = 0; j< m_tempsAtterDecol; j++)
    {
        m_piste[i].first.push(Type_avion("vide",0,0));
    }
    m_piste[i].first.push(plane);
    m_piste[i].second = "aterrissage";
}

void Aeroport::decollage(int i, Type_avion plane)
{
    for(int j = 0; j< m_tempsAtterDecol; j++)
    {
        m_piste[i].first.push(Type_avion("vide",0,0));
    }

    m_piste[i].first.push(plane);
    m_piste[i].second = "decollage";
}

void Aeroport::fileTransitionSortie(Type_avion plane)
{
    for(int i = 0; i< m_tempsAntiCol; i++)
    {
        m_transitionSortie.push(Type_avion("vide",0,0));
    }
    m_transitionSortie.push(plane);
}

void Aeroport::fileTransitionEntree(Type_avion plane)
{
    for(int i = 0; i< m_tempsAntiCol; i++)
    {
        m_transitionEntree.push(Type_avion("vide",0,0));
    }
    m_transitionEntree.push(plane);
}

void Aeroport::zoneStockage(Type_avion plane)
{
    for(int i = 0; i< m_delaiAttenteSol; i++)
    {
        m_stockage.push(Type_avion("vide",0,0));
    }
    m_stockage.push(plane);
}

void Aeroport::zoneAttente(Type_avion plane)
{
    for(int i = 0; i< m_tempsBoucleAttente; i++)
    {
        m_boucleAttente.push(Type_avion("vide",0,0));
    }
    m_boucleAttente.push(plane);
}

void Aeroport::defilerBoucleAttente()
{
    Type_avion temp = m_boucleAttente.front();
    m_boucleAttente.pop();
    bool done = false;
    int retour = 0;

    if(temp.GetType() != "vide")
    {
        for(int i = 0; i<m_nombrePistes;i++)
        {
            if (m_piste[i].second == "libre" && done == false)
            {
                decollage(i, temp);
                done =true;
            }
            else
            {
                retour++;
            }
        }

        if(retour ==m_nombrePistes)
        {
            zoneAttente(temp);
        }
    }
}

void Aeroport::defilerZoneStockage()
{
    Type_avion temp = m_stockage.front();
    m_stockage.pop();

    if(temp.GetType() != "vide")
    {
        fileTransitionSortie(temp);
    }
}


void Aeroport::defilerTransSortie()
{
    Type_avion temp = m_transitionSortie.front();
    m_transitionSortie.pop();
    bool done = false;

    if(temp.GetType() != "vide")
    {
        for(int i = 0; i<m_nombrePistes;i++)
        {
            if (m_piste[i].second == "libre" && done == false)
            {
                decollage(i, temp);
                done =true;
            }
        }
    }
}

void Aeroport::defilerTransEntree()
{
    Type_avion temp = m_transitionEntree.front();
    m_transitionEntree.pop();

    if(temp.GetType() != "vide")
    {
        m_stockage.push(temp);
    }
}

void Aeroport::defilerPiste(int i)
{

    Type_avion temp = m_piste[i].first.front();
    m_piste[i].first.pop();
    if(temp.GetType() != "vide")
    {
        if(m_piste[i].second == "aterrissage")
        {
            fileTransitionEntree(temp);
        }
        else if(m_piste[i].second == "decollage")
        {
             decoco(temp, m_nom);
        }
    }
}
