#include "header.h"
Vol::Vol()
{
    //rien a faire
}
Vol::Vol(Aeroport aero_dep,Aeroport aero_arr,Type_avion avion)
{
  m_aero_dep=aero_dep;
  m_aero_arr=aero_arr;
  m_avion=avion;
  m_fin=false;

}

Type_avion Vol::Getavion()const
{
    return m_avion;
}

void Vol::SetAvion(Type_avion av)
{
    m_avion=av;
}

void Vol::etatav()
{
    if(m_aero_dep.GetNom()=="New-York") m_etat_av= true;
    if(m_aero_dep.GetNom()=="Tokyo") m_etat_av=false;
    if(m_aero_dep.GetNom()=="Sydney")
    {
      if(m_aero_arr.GetNom()=="Tokyo")
      {
          m_etat_av=true;
      }
      else
      {
        m_etat_av=false;

      }

    }
    if(m_aero_dep.GetNom()=="Bangkok")
    {
      if(m_aero_arr.GetNom()=="Tokyo"||m_aero_arr.GetNom()=="Sydney")
      {
          m_etat_av=true;
      }
      else
      {
        m_etat_av=false;

      }

    }
    if(m_aero_dep.GetNom()=="Alger")
    {
      if(m_aero_arr.GetNom()=="New-York"||m_aero_arr.GetNom()=="Londres"||m_aero_arr.GetNom()=="Brasilia")
      {
          m_etat_av=false;
      }
      else
      {
        m_etat_av=true;

      }

    }
    if(m_aero_dep.GetNom()=="Londres")
    {
      if(m_aero_arr.GetNom()=="New-York"||m_aero_arr.GetNom()=="Brasilia")
      {
          m_etat_av=false;
      }
      else
      {
        m_etat_av=true;

      }

    }
    if(m_aero_dep.GetNom()=="Brasilia")
    {
      if(m_aero_arr.GetNom()=="New-York")
      {
          m_etat_av=false;
      }
      else
      {
        m_etat_av=true;

      }

    }
}
std::vector<Aeroport> Vol::Get_PCC()const
{
    return m_PCC;
}
void Vol::Set_PCC(std::vector<Aeroport> PCC)
{
    m_PCC=PCC;
}
int Vol::Get_indPCC()const
{
    return m_indPCC;
}
void Vol::Set_indPCC(int PCC)
{
    m_indPCC=PCC;
}

Aeroport Vol::Getdep()const
{
    return m_aero_dep;
}

Aeroport Vol::GetArr()const
{
    return m_aero_arr;
}

int Vol::GetArx()const
{
    return m_Arx;
}

int Vol::GetAry()const
{
    return m_Ary;
}

void Vol::SetArx(int Arx)
{
        m_Arx=Arx;
}

void Vol::SetAry(int Ary)
{
        m_Ary=Ary;
}

int Vol::GetDepx()
{
        return m_Depx;
}

int Vol::GetDepy()
{
        return m_Depy;
}

bool Vol::GetEtat()
{
    return m_etat_av;
}
bool Vol::GetFin()
{
    return m_fin;
}
void Vol::SetEtat(bool _etat_av)
{
    m_etat_av = _etat_av;
}
void Vol::SetFin(bool _fin)
{
    m_fin = _fin;
}
void Vol::SetDepx(int x)
{
         m_Depx=x;
}

void Vol::SetDepy(int y)
{
        m_Depy=y;
}

void Vol::Setdep(Aeroport vol)
{
    m_aero_dep=vol;
}

void Vol::SetArr(Aeroport vol)
{
    m_aero_arr=vol;
}
