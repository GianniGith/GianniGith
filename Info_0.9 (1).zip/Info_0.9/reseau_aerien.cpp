#include "header.h"

Reseau_aerien::Reseau_aerien()
{
    int ordre,taille,dist;
    std::string ville1,ville2;
    ///REMPLISSAGE M_AEROPORT
    chargementAeroports();
    std::ifstream ifs{"reseau_aerien.txt"};//on ouvre notre fichier reseau
    if(!ifs)
        throw std::runtime_error( "Impossible d'ouvrir en lecture donneesAero.txt" );
    ifs >> ordre;
    SetOrdre(ordre); //lecture de l'ordre de notre reseau (nb aeroports)
    if(ifs.fail())
        throw std::runtime_error("Probleme lecture ordre du graphe");
    //on alloue la place pour chaque sommet
    m_reseau_aerien.resize(m_ordre);
    ifs >> taille;//on lit le nbr de chemin
    SetTaille(taille);
    if(ifs.fail())
        throw std::runtime_error("Probleme lecture taille du graphe");
    for(int i=0;i<m_taille;++i)//on relis chaque aeroport � un autre
    {

        ifs>>ville1>>ville2>>dist;
        if(ifs.fail())
            throw std::runtime_error("Probleme lecture chemins");
        m_reseau_aerien[indAeroport(ville1)].push_back(std::make_pair((m_aeroports[indAeroport(ville2)]),dist));

    }
}

void Reseau_aerien::chargementAeroports()
{
    std::ifstream ifs{"donneesAero.txt"};
    for(int i = 0; i< 7; i++)
    {
        m_aeroports.push_back(Aeroport());
        if (!ifs) //Si probleme d'ouverture du ficher
        {
            throw std::runtime_error( "Impossible d'ouvrir en lecture donneesAero.txt" ); //Traitement et renvoi de l'erreur associee
        }
        std::string _nom;
        ifs>> _nom;
        if ( ifs.fail() ) //Si probleme de lecture de l'ordre
        {
            throw std::runtime_error("Probleme lecture nom");
        }
        m_aeroports[i].setNom(_nom);

        int _nbPistes;
        ifs>> _nbPistes;
        if ( ifs.fail() ) //Si probleme de lecture de l'ordre
        {
            throw std::runtime_error("Probleme lecture nbPlaceAuSol");
        }
        m_aeroports[i].setNombrePistes(_nbPistes);

        int _nbPlaceSol;
        ifs>> _nbPlaceSol;
        if ( ifs.fail() ) //Si probleme de lecture de l'ordre
        {
            throw std::runtime_error("Probleme lecture nbPlaceAuSol");
        }
        m_aeroports[i].setNbPlacesAuSol(_nbPlaceSol);

        int _delAtSol;
        ifs>> _delAtSol;
        if ( ifs.fail() ) //Si probleme de lecture de l'ordre
        {
            throw std::runtime_error("Probleme lecture delaiAttenteSol");
        }
        m_aeroports[i].setDelaiAttenteSol(_delAtSol);

        int _tempsAccesPiste;
        ifs>> _tempsAccesPiste;
        if ( ifs.fail() ) //Si probleme de lecture de l'ordre
        {
            throw std::runtime_error("Probleme lecture tempsAccesPiste");
        }
        m_aeroports[i].setTempsAccesPiste(_tempsAccesPiste);

        int _tempsAtterDecol;
        ifs>> _tempsAtterDecol;
        if ( ifs.fail() ) //Si probleme de lecture de l'ordre
        {
            throw std::runtime_error("Probleme lecture tempsAtterDecol");
        }
        m_aeroports[i].setTempsAtterDecol(_tempsAtterDecol);

        int _tempsAntiCol;
        ifs>> _tempsAntiCol;
        if ( ifs.fail() ) //Si probleme de lecture de l'ordre
        {
            throw std::runtime_error("Probleme lecture tempsAntiCol");
        }
        m_aeroports[i].setTempsAntiCol(_tempsAntiCol);

        int _tempsBoucleAttente;
        ifs>> _tempsBoucleAttente;
        if ( ifs.fail() ) //Si probleme de lecture de l'ordre
        {
            throw std::runtime_error("Probleme lecture tempsBoucleAttente");
        }
        m_aeroports[i].setTempsBoucleAttente(_tempsBoucleAttente);

        int _PosX;
        ifs>> _PosX;
        if ( ifs.fail() ) //Si probleme de lecture de l'ordre
        {
            throw std::runtime_error("Probleme lecture PosX");
        }
        m_aeroports[i].setPosX(_PosX);

        int _PosY;
        ifs>> _PosY;
        if ( ifs.fail() ) //Si probleme de lecture de l'ordre
        {
            throw std::runtime_error("Probleme lecture PosY");
        }
        m_aeroports[i].setPosY(_PosY);

        m_aeroports[i].setTempsBoucleAttente(_tempsBoucleAttente);







        m_aeroports[i].remplissageAvions();
    }
}

void Reseau_aerien::afficherAeroports()
{
    for(int i = 0; i< GetOrdre() ; i++)
    {
        GetAeroports().at(i).Afficher();
    }
}

//Fonction qui retourne l'indice en fct du nom de l'aeroport
int Reseau_aerien::indAeroport(std::string nom)
{
    int temp =-1;
    for(int i=0;i<m_ordre;i++)
    {
        if(m_aeroports[i].GetNom() == nom)
        {
             temp = i; //retourne l'indice de l'aeroport dans notre vecteur
        }

    }
    return temp;
}

//Sous-programme pour trouver le plus court chemin
int Reseau_aerien::Dijkstra(int a1, int a2, std::vector<int> *predecesseurs,std::string type)
{
    int cpt;
    std::vector<int> distances(GetOrdre(), std::numeric_limits<int>::max()); //vecteur de la taille du nbr d'aeroport, contient la distance d'un aeroport initiale a un autre
    //distance[i] correspond � la distance du noeud de depart au noeud i
    distances[a1] = 0;//init a 0 pour aeroport initial

    std::vector<int> parents(m_ordre, -1); //Vecteur contenant les pr�d�cesseurs du sommet final permettant d'aller jusqu'au sommet initial

    //on utilise la classe priority queue de 2 classe pair  avec une fct de comparaison
    //notre comparateur nous permet de mettre le chemin le plus proche au haut
    std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, decltype(comp)> Q(comp);//chaque pair correspond a un aeroport et sa distance
    Q.push(std::make_pair(a1,0));//on init la queue prioritaire par le sommet de depart

    while(!Q.empty())//tant que la queue n'est pas vide
    {
        int a = Q.top().first;//on prend l'index du sommet le plus proche
        int b = Q.top().second;//prend en memoire la distance
        Q.pop();

        if(b <= distances[a])
        {
            for(const auto& i : m_reseau_aerien.at(a)) // on parcourt le graphe � l'index du sommet a
            {
                auto a2 = indAeroport(i.first.GetNom());//ind aeroport connect� a a
                auto b2 = i.second;//poid du chemin

                if(type=="long")
                {
                    if(distances[a] + b2 < distances[a2] && (distances[a] + b2 <= 18000 || (distances[a] + b2 <= 18000*cpt-distances[a2])))//si distance de l'aeroport � a2 est plus court que l'ancien
                    {
                      distances[a2] = distances[a] + b2;//on reajuste la distance
                      parents[a2] = a; //actualise le parnet
                      cpt++;
                      Q.push(std::make_pair(a2, distances[a2]));//on ajoute le nv sommet
                    }
                }
                else if(type=="moyen")
                {
                    if(distances[a] + b2 < distances[a2] && (distances[a] + b2 <= 14500 || (distances[a] + b2 <= 14500*cpt-distances[a2])))//si distance de l'aeroport � a2 est plus court que l'ancien
                    {
                      distances[a2] = distances[a] + b2;//on reajuste la distance
                      parents[a2] = a; //actualise le parnet
                      cpt++;
                      Q.push(std::make_pair(a2, distances[a2]));//on ajoute le nv sommet
                    }
                }
                else if(type=="court")
                {
                    if(distances[a] + b2 < distances[a2] && (distances[a] + b2 <= 8750 || (distances[a] + b2 <= 8750*cpt-distances[a2])))//si distance de l'aeroport � a2 est plus court que l'ancien
                    {
                      distances[a2] = distances[a] + b2;//on reajuste la distance
                      parents[a2] = a; //actualise le parnet
                      cpt++;
                      Q.push(std::make_pair(a2, distances[a2]));//on ajoute le nv sommet
                    }
                }
            }
        }
    }

    predecesseurs->push_back(a2);


    for (auto p = parents[a2]; p != -1; p = parents[p]) //Parcours des pr�d�cesseurs
    {
        predecesseurs->push_back(p);
    }

    std::reverse(predecesseurs->begin(), predecesseurs->end());

    return distances[a2];
}

void Reseau_aerien::AffichagePCC()
{
    std::vector<int>::iterator it;
    std::vector<int> parents(GetOrdre(),-1);
    std::string A1,type;
    std::vector<int> distances;

    do
    {
        std::cout<<"\nSAISIR LE NOM DE L'AEROPORT DE DEPART : "<<std::endl;
        std::cin>>A1;
    }while(A1 != "New-York" && A1 != "Londres" && A1 != "Brasilia" && A1 != "Alger" && A1 != "Tokyo" && A1 != "Sydney" && A1 != "Bangkok");

    do
    {
        std::cout<<"\nSAISIR LE TYPE D'AVION : court/moyen/long"<<std::endl;
        std::cin>>type;
    }while(type!="court" && type !="moyen" && type!="long");

    for (int i = 0; i< m_ordre; i++)
    {
        m_listePrede[i].first = Dijkstra(indAeroport(A1),i, &m_listePrede[i].second,type);

        std::cout << "Chemin permettant d'aller de " << A1 << " a " << m_aeroports[i].GetNom() << " :" << std::endl;

        if(m_listePrede[i].first<45000){
            std::cout<< m_aeroports[*m_listePrede[i].second.begin()].GetNom();
        }else{
            std::cout<<"Pas de chemin possible pour un avion de type "<<type;
        }

        for (it = m_listePrede[i].second.begin()+1; it!=m_listePrede[i].second.end(); it++)
        {

            std::cout<< "-->" << m_aeroports[*it].GetNom();
        }

        if(m_listePrede[i].first>45000)
        {
            m_listePrede[i].first = 0;
        }
        std::cout <<std::endl << "Distance entre " << A1 << " et " << m_aeroports[i].GetNom() << " :" << m_listePrede[i].first <<" kilometres"<< std::endl<< std::endl;

    }
    //GetAeroports().at(indAeroport(A1)).Afficher();
    //GetAeroports().at(indAeroport(A1)).remplissageAvions();

}
//Getters
int Reseau_aerien::GetOrdre()const
{
    return m_ordre;
}
int Reseau_aerien::GetTaille()const
{
    return m_taille;
}
std::vector<Aeroport> Reseau_aerien::GetAeroports()const
{
    return m_aeroports;
}
std::vector<std::vector<std::pair<Aeroport, int>>> Reseau_aerien::GetReseauAerien()const
{
    return m_reseau_aerien;
}
//Setters
void Reseau_aerien::SetOrdre(int _ordre)
{
    m_ordre=_ordre;
}
void Reseau_aerien::SetTaille(int _taille)
{
    m_taille=_taille;
}
void Reseau_aerien::SetAeroports(std::vector<Aeroport> _aeroports)
{
    m_aeroports=_aeroports;
}
void Reseau_aerien::SetReseauAerien(std::vector<std::vector<std::pair<Aeroport, int>>> _reseau_aerien)
{
    m_reseau_aerien=_reseau_aerien;
}
