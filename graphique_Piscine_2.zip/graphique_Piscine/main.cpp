#include <iostream>
#include <allegro.h>

void initialisationAllegro();

int main()
{
    initialisationAllegro();
    BITMAP *Carte ;
    BITMAP *Infos;
    BITMAP *buffer;

    Carte= load_bitmap("carte.bmp",NULL);
    Infos= load_bitmap("infos.bmp",NULL);
    show_mouse(screen);
    buffer=create_bitmap(SCREEN_W,SCREEN_H);



    while(!key[KEY_ESC])
    {
            blit(Carte,screen,0,0, (SCREEN_W-Carte->w)/2, (SCREEN_H-Carte->h)/2, Carte->w, Carte->h);
            //if(key[KEY_SPACE]);
            //{
            masked_blit(Infos,screen,0,0, (SCREEN_W-Infos->w)/2, (SCREEN_H-Infos->h)/2, Infos->w, Infos->h);
            buffer=create_bitmap(SCREEN_W,SCREEN_H);
    clear_bitmap(buffer);
           // }

           textprintf_ex(screen, font, 0, 20, makecol(0, 255, 255),-1, "Coordonn�es dela souris en ligne : %d et en colonne : %d", mouse_y, mouse_x);
    }



//textprintf_ex(screen, font, 0, 20, makecol(0, 255, 255), "Coordonn�es de x : %d ,y : %d " , mouse_y, mouse_x);
//texprint


    return 0;
}END_OF_MAIN()

void initialisationAllegro()
{

    allegro_init();
    install_keyboard();
    install_timer();
    install_mouse();

    set_color_depth(desktop_color_depth());

    if(set_gfx_mode(GFX_AUTODETECT_FULLSCREEN,1920,1080,0,0)!=0)
    {
        allegro_message("Probleme de mode graphique");
        allegro_exit();
        exit(EXIT_FAILURE);


}

}
