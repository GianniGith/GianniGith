#include "header.h"

void Initialisation()
{
    allegro_init();
    set_uformat(U_ASCII);
    install_keyboard();
    install_mouse();
}

void visualisation_graphique()
{
    set_gfx_mode(GFX_AUTODETECT,640,480,0,0);

    BITMAP *image1;

    image1 = load_bitmap("Monde.bmp",NULL);

    while (!key[KEY_ESC])
    {
        blit(image1,screen,0,0,0,0,640,480);
    }
    destroy_bitmap(image1);

}
