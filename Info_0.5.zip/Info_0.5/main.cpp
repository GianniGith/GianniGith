#include "header.h"

int main()
{
    Initialisation();
    Menu menu = Menu();
    menu.menuto();
    allegro_exit();
    return 0;

}END_OF_MAIN() ;
